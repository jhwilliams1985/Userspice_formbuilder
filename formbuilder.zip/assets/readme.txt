Classes, javascript, css and other assets go here. 
