<?php
require_once("init.php");
//For security purposes, it is MANDATORY that this page be wrapped in the following
//if statement. This prevents remote execution of this code.
if (in_array($user->data()->id, $master_account)){


$db = DB::getInstance();
include "plugin_info.php";



//all actions should be performed here.
$check = $db->query("SELECT NULL FROM us_plugins WHERE plugin = ?",array($plugin_name))->count();
if($check > 0){
	err($plugin_name.' has already been installed!');
}else{
 $fields = array(
	 'plugin'=>$plugin_name,
	 'status'=>'installed',
 );
 $db->insert('us_plugins',$fields);
 if(!$db->error()) {
	 	err($plugin_name.' installed');
		logger($user->data()->id,"USPlugins",$plugin_name." installed");
 } else {
	 	err($plugin_name.' was not installed');
		logger($user->data()->id,"USPlugins","Failed to to install plugin, Error: ".$db->errorString());
 }
}


$fb_formbuilder = 'fb_formbuilder';

$columns = "
    (
    `id` INT NOT NULL AUTO_INCREMENT ,
    `form` VARCHAR(255) NOT NULL ,
    PRIMARY KEY (`id`)
    ) ENGINE = InnoDB
    ";
$db->query("CREATE TABLE IF NOT EXISTS `$fb_formbuilder` $columns");

$check = $db->query("SELECT NULL FROM fb_formbuilder WHERE form = ?",['fb_settings'])->count();
if($check < 1){
$insert_settings = array(
    'form' => 'fb_settings',
);
$db->insert($fb_formbuilder,$insert_settings);
}

$fb_settings = "fb_settings";
$columns2 = "(
    `id` INT(11) NOT NULL AUTO_INCREMENT ,
    `div_class` VARCHAR(255) NULL ,
    `label_class` VARCHAR(255) NULL ,
    `input_class` VARCHAR(255) NULL ,
    `type_html` VARCHAR(255) NULL ,
    PRIMARY KEY (`id`)) ENGINE = InnoDB;
    ";
$db->query("CREATE TABLE IF NOT EXISTS `$fb_settings` $columns2");

$check = $db->query("SELECT NULL FROM fb_settings WHERE install_check = ?",[1])->count();
if($check < 1){
$insert = array(
    'div_class' => 'form-group',
    'label_class' => 'form-group',
    'input_class' => 'form-control',
	'install_check' => 1
);
$db->insert($fb_settings,$insert);
}


$database_fb_fields = $fb_settings.'_fb_fields';
$columns3 = "(
    `id` INT(11) NOT NULL AUTO_INCREMENT ,
    `fb_order` INT(11) NOT NULL ,
    `name` VARCHAR(255) NOT NULL ,
    `field_type` TEXT NOT NULL ,
    `field_html` TEXT NOT NULL ,
    `requirements` TEXT NOT NULL ,
    `databasevalue` VARCHAR(255) NULL DEFAULT NULL ,
    `database_name` VARCHAR(255) NULL DEFAULT NULL ,
    `database_value` VARCHAR(255) NULL DEFAULT NULL ,
    `database_where` VARCHAR(255) NULL DEFAULT NULL ,
    PRIMARY KEY (`id`)) ENGINE = InnoDB;
    ";
$db->query("CREATE TABLE IF NOT EXISTS `$database_fb_fields` $columns3");

$check = $db->query("SELECT NULL FROM fb_settings_fb_fields WHERE fb_order = 1")->count();
if($check < 1){
$insert1 = array(
    'fb_order' => '1',
    'name' => 'div_class',
    'field_type' => 'text',
    'field_html' => '{"div_class":"form-group","label":"div Class: (DEFAULT)","label_class":"form-group","input_class":"form-control","input_html":"","required":"No","input_step":""}'
);
$insert2 = array(
    'fb_order' => '2',
    'name' => 'label_class',
    'field_type' => 'text',
    'field_html' => '{"div_class":"form-group","label":"Label Class: (DEFAULT)","label_class":"form-group","input_class":"form-control","input_html":"","required":"No","input_step":""}'
);
$insert3 = array(
    'fb_order' => '3',
    'name' => 'input_class',
    'field_type' => 'text',
    'field_html' => '{"div_class":"form-group","label":"Input Class: (DEFAULT)","label_class":"form-group","input_class":"form-control","input_html":"","required":"No","input_step":""}'
);
$insert4 = array(
    'fb_order' => '4',
    'name' => 'type_html',
    'field_type' => 'text',
    'field_html' => '{"div_class":"form-group","label":"Type HTML: (DEFAULT)","label_class":"form-group","input_class":"form-control","input_html":"","required":"No","input_step":""}'
);
$db->insert($database_fb_fields,$insert1);
$db->insert($database_fb_fields,$insert2);
$db->insert($database_fb_fields,$insert3);
$db->insert($database_fb_fields,$insert4);
}

//do you want to inject your plugin in the middle of core UserSpice pages?
$hooks = [];

//The format is $hooks['userspicepage.php']['position'] = path to filename to include
//Note you can include the same filename on multiple pages if that makes sense;
//postion options are post,body,form,bottom
//See documentation for more information
// $hooks['login.php']['body'] = 'hooks/loginbody.php';
// $hooks['login.php']['form'] = 'hooks/loginform.php';
// $hooks['login.php']['bottom'] = 'hooks/loginbottom.php';
// $hooks['login.php']['post'] = 'hooks/loginpost.php';
registerHooks($hooks,$plugin_name);

} //do not perform actions outside of this statement
